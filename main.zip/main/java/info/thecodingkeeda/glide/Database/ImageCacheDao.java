package info.thecodingkeeda.glide.Database;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

import static android.arch.persistence.room.OnConflictStrategy.REPLACE;


@Dao
public interface ImageCacheDao {

    @Insert(onConflict = REPLACE)
    void insertImageData(ImageCache imageCache);


    @Query("SELECT images FROM ic")
    List<String> getImageData();

    @Query("SELECT images FROM ic WHERE search=:mString ")
    List<String> getSpecificImageData(String mString);

    @Delete
    void deleteImageData(ImageCache imageCache);
}
