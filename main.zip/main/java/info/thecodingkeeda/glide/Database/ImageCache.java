package info.thecodingkeeda.glide.Database;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.arch.persistence.room.TypeConverters;
import android.support.annotation.NonNull;

import java.util.ArrayList;


@Entity(tableName = "ic")
public class ImageCache {
    @PrimaryKey
    @NonNull
            @ColumnInfo(name = "search")
    String mString;

    @NonNull
    public String getString() {
        return mString;
    }

    public void setString(@NonNull String string) {
        mString = string;
    }

    public ArrayList<String> getImages() {
        return mImages;
    }

    public void setImages(ArrayList<String> images) {
        mImages = images;
    }

    @TypeConverters(Converters.class)
            @ColumnInfo(name = "images")
    ArrayList<String> mImages;

}
